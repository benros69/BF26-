import React from 'react';
import { Link } from 'react-router-dom';
import { Sun } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="bg-[#2F4F2F] text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="flex items-center space-x-2">
          <Sun className="h-8 w-8" />
          <span className="text-2xl font-bold">BF26</span>
        </Link>
        <div className="flex items-center space-x-6">
          <Link to="/" className="hover:text-gray-300">Accueil</Link>
          <Link to="/about" className="hover:text-gray-300">A PROPOS DE NOUS</Link>
          <Link to="/projects" className="hover:text-gray-300">Projets Réalisés</Link>
          <Link to="/faq" className="hover:text-gray-300">FAQ</Link>
          <a href="tel:0663932444" className="bg-[#2A2D43] px-4 py-2 rounded-full hover:bg-opacity-90">
            0663932444
          </a>
        </div>
      </div>
    </nav>
  );
}