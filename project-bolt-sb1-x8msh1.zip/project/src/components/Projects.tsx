import React from 'react';

const projects = [
  {
    title: "Hangar Agricole en Construction",
    location: "Rhône-Alpes",
    surface: "800m²",
    production: "120 kWc",
    status: "En cours de réalisation",
    image: "https://images.unsplash.com/photo-1530905147135-965a3a2b5c0d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "Installation Industrielle",
    location: "Auvergne",
    surface: "1200m²",
    production: "180 kWc",
    status: "Chantier en cours",
    image: "https://images.unsplash.com/photo-1574159517763-57d2a88365f7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "Entrepôt Logistique",
    location: "Loire",
    surface: "2000m²",
    production: "300 kWc",
    status: "Phase finale",
    image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
  }
];

const testimonials = [
  {
    name: "Pierre Martin",
    company: "Ferme Martin & Fils",
    content: "Le suivi du chantier était impeccable. BF26 nous a tenus informés à chaque étape de la construction.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
  },
  {
    name: "Sophie Dubois",
    company: "Logistique Express",
    content: "Un travail professionnel et des délais respectés. Notre hangar photovoltaïque est exactement ce dont nous avions besoin.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
  }
];

export default function Projects() {
  return (
    <div className="bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-8">Nos Projets en Cours</h1>
        <p className="text-xl text-gray-600 text-center max-w-3xl mx-auto mb-16">
          Découvrez nos chantiers en cours de réalisation. Chaque projet est unique et adapté aux besoins spécifiques de nos clients.
        </p>
        
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {projects.map((project, index) => (
            <div key={index} className="bg-white rounded-lg overflow-hidden shadow-lg">
              <img 
                src={project.image}
                alt={project.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="mb-4">
                  <span className="bg-[#9FE870] text-[#2F4F2F] px-3 py-1 rounded-full text-sm">
                    {project.status}
                  </span>
                </div>
                <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                <div className="space-y-2 text-gray-600">
                  <p>📍 {project.location}</p>
                  <p>📏 Surface: {project.surface}</p>
                  <p>⚡ Production prévue: {project.production}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-lg p-8 shadow-lg mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">Témoignages de Nos Clients</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  <img 
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-semibold">{testimonial.name}</h4>
                    <p className="text-gray-600 text-sm">{testimonial.company}</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">"{testimonial.content}"</p>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center">
          <p className="text-xl text-gray-600 mb-8">
            Votre projet sera peut-être notre prochaine réussite
          </p>
          <a 
            href="/contact"
            className="inline-block bg-[#2F4F2F] text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-opacity-90 transition-all"
          >
            Démarrer Votre Projet →
          </a>
        </div>
      </div>
    </div>
  );
}