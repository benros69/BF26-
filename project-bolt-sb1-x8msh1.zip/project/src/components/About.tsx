import React from 'react';
import { Shield, Sun, Users, Award } from 'lucide-react';

export default function About() {
  return (
    <div className="bg-white">
      <div className="relative py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold text-center mb-16">À Propos de BF26</h1>
          
          <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-3xl font-semibold mb-6">Notre Expertise en Énergie Solaire</h2>
              <p className="text-gray-600 mb-6">
                BF26 est un bureau d'études spécialisé dans la conception et la réalisation de hangars photovoltaïques. 
                Notre expertise nous permet d'offrir des solutions sur mesure qui combinent fonctionnalité et production 
                d'énergie renouvelable.
              </p>
              <p className="text-gray-600">
                Basés à Villeurbanne, nous intervenons dans toute la région pour accompagner nos clients dans leur 
                transition énergétique, de l'étude initiale jusqu'à la réalisation complète de leur projet.
              </p>
            </div>
            <div>
              <img 
                src="https://images.unsplash.com/photo-1591696205602-2f950c417cb9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                alt="Équipe BF26"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-8 mb-16">
            <div className="text-center p-6 bg-gray-50 rounded-lg">
              <Shield className="w-12 h-12 mx-auto mb-4 text-[#2F4F2F]" />
              <h3 className="text-xl font-semibold mb-2">Fiabilité</h3>
              <p className="text-gray-600">Des solutions durables et performantes</p>
            </div>
            <div className="text-center p-6 bg-gray-50 rounded-lg">
              <Sun className="w-12 h-12 mx-auto mb-4 text-[#2F4F2F]" />
              <h3 className="text-xl font-semibold mb-2">Innovation</h3>
              <p className="text-gray-600">Technologies de pointe</p>
            </div>
            <div className="text-center p-6 bg-gray-50 rounded-lg">
              <Users className="w-12 h-12 mx-auto mb-4 text-[#2F4F2F]" />
              <h3 className="text-xl font-semibold mb-2">Accompagnement</h3>
              <p className="text-gray-600">Support personnalisé</p>
            </div>
            <div className="text-center p-6 bg-gray-50 rounded-lg">
              <Award className="w-12 h-12 mx-auto mb-4 text-[#2F4F2F]" />
              <h3 className="text-xl font-semibold mb-2">Expertise</h3>
              <p className="text-gray-600">Plus de 10 ans d'expérience</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}