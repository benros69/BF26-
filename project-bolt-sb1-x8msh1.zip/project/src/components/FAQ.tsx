import React from 'react';

const faqs = [
  {
    question: "Quelle est la durée moyenne d'installation d'un hangar photovoltaïque ?",
    answer: "La durée d'installation varie selon la taille du projet, généralement entre 2 et 4 semaines pour un hangar standard. Cette période comprend le montage de la structure et l'installation des panneaux solaires."
  },
  {
    question: "Quelles sont les démarches administratives nécessaires ?",
    answer: "Nous nous occupons de l'ensemble des démarches administratives : permis de construire, raccordement au réseau, dossiers de subventions. Notre équipe vous accompagne à chaque étape."
  },
  {
    question: "Quelle est la rentabilité d'un hangar photovoltaïque ?",
    answer: "La rentabilité dépend de plusieurs facteurs (ensoleillement, surface, consommation). En moyenne, le retour sur investissement se situe entre 7 et 10 ans, avec une durée de vie des installations de 25+ ans."
  },
  {
    question: "Proposez-vous des solutions de financement ?",
    answer: "Oui, nous travaillons avec plusieurs partenaires financiers pour vous proposer des solutions adaptées : prêts verts, location avec option d'achat, ou financement participatif."
  },
  {
    question: "Quelle maintenance est nécessaire ?",
    answer: "Nous recommandons une inspection annuelle pour optimiser les performances. Notre service maintenance assure le suivi, le nettoyage et les interventions si nécessaire."
  }
];

export default function FAQ() {
  return (
    <div className="bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-16">Questions Fréquentes</h1>
        
        <div className="max-w-3xl mx-auto">
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div 
                key={index}
                className="bg-white rounded-lg p-6 shadow-md"
              >
                <h3 className="text-xl font-semibold mb-3">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-xl mb-6">
              Vous avez d'autres questions ? N'hésitez pas à nous contacter !
            </p>
            <div className="space-x-4">
              <a 
                href="tel:0663932444"
                className="inline-block bg-[#2F4F2F] text-white px-6 py-3 rounded-full hover:bg-opacity-90 transition-all"
              >
                Appeler : 06.63.93.24.44
              </a>
              <a 
                href="mailto:bureaudetudebf26@gmail.com"
                className="inline-block bg-[#9FE870] text-[#2F4F2F] px-6 py-3 rounded-full hover:bg-opacity-90 transition-all"
              >
                Envoyer un Email
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}