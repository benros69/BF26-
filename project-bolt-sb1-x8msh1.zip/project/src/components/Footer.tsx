import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#2F4F2F] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">BF26</h3>
            <p className="text-gray-300">
              Bureau d'étude spécialisé en économie d'Énergie et photovoltaïque
            </p>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">Contact</h3>
            <div className="space-y-2">
              <p className="flex items-center">
                <Mail className="w-5 h-5 mr-2" />
                bureaudetudebf26@gmail.com
              </p>
              <p className="flex items-center">
                <Phone className="w-5 h-5 mr-2" />
                06.63.93.24.44
              </p>
              <p className="flex items-center">
                <MapPin className="w-5 h-5 mr-2" />
                8 rue de la convention<br />69100 VILLEURBANNE
              </p>
            </div>
          </div>
          
          <div className="col-span-2">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2783.2835673075897!2d4.886281776271842!3d45.76006587108091!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f4c0213d1a6f3d%3A0x2a8f2f4b7c7c7c7c!2s8%20Rue%20de%20la%20Convention%2C%2069100%20Villeurbanne!5e0!3m2!1sfr!2sfr!4v1620000000000!5m2!1sfr!2sfr"
              width="100%"
              height="200"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="rounded-lg"
            ></iframe>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-600 text-center">
          <p className="text-gray-400">
            © {new Date().getFullYear()} BF26. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
}