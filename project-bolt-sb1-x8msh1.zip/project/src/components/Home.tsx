import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Sun, Battery, Leaf } from 'lucide-react';

export default function Home() {
  const testimonials = [
    {
      name: "Jean Dupont",
      role: "Agriculteur",
      content: "Grâce à BF26, j'ai pu optimiser mon exploitation avec un hangar photovoltaïque qui me permet de stocker mon matériel tout en produisant de l'énergie. Un investissement rentable et écologique !",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
    },
    {
      name: "Marie Laurent",
      role: "Directrice Logistique",
      content: "L'équipe de BF26 a été très professionnelle du début à la fin. Le hangar solaire répond parfaitement à nos besoins et nous permet de réduire significativement notre empreinte carbone.",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
    }
  ];

  return (
    <div>
      <div className="relative h-screen">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1613665813446-82a78c468a1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80" 
            alt="Hangar solaire" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        </div>
        
        <div className="relative container mx-auto px-4 h-full flex items-center">
          <div className="max-w-3xl text-white">
            <h1 className="text-6xl font-bold mb-8 leading-tight">
              Construisez Votre Avenir Durable avec BF26
            </h1>
            <p className="text-xl mb-8 leading-relaxed">
              Expert en conception et réalisation de hangars photovoltaïques, BF26 vous accompagne dans votre transition énergétique. Nos solutions innovantes combinent stockage optimal et production d'énergie verte pour une rentabilité maximale.
            </p>
            <div className="space-x-6">
              <Link 
                to="/contact"
                className="inline-block bg-[#9FE870] text-[#2F4F2F] px-8 py-4 rounded-full text-lg font-semibold hover:bg-opacity-90 transition-all"
              >
                Demandez une Étude Gratuite →
              </Link>
              <Link
                to="/projects"
                className="inline-block bg-white bg-opacity-20 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-opacity-30 transition-all"
              >
                Voir Nos Réalisations
              </Link>
            </div>
          </div>
        </div>
      </div>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold mb-6">Pourquoi Choisir BF26 ?</h2>
            <p className="text-xl text-gray-600">
              Notre expertise technique et notre engagement envers la qualité font de nous le partenaire idéal pour votre projet de hangar photovoltaïque.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-20">
            <div className="text-center p-6">
              <Sun className="w-16 h-16 mx-auto mb-6 text-[#2F4F2F]" />
              <h3 className="text-2xl font-semibold mb-4">Expertise Technique</h3>
              <p className="text-gray-600">
                Notre bureau d'études possède une expertise pointue dans la conception de structures photovoltaïques optimisées pour votre activité.
              </p>
            </div>
            <div className="text-center p-6">
              <Battery className="w-16 h-16 mx-auto mb-6 text-[#2F4F2F]" />
              <h3 className="text-2xl font-semibold mb-4">Performance Garantie</h3>
              <p className="text-gray-600">
                Nos installations sont conçues pour maximiser la production d'énergie tout en assurant une durabilité exceptionnelle.
              </p>
            </div>
            <div className="text-center p-6">
              <Leaf className="w-16 h-16 mx-auto mb-6 text-[#2F4F2F]" />
              <h3 className="text-2xl font-semibold mb-4">Impact Environnemental</h3>
              <p className="text-gray-600">
                Contribuez à la transition énergétique tout en bénéficiant d'un espace de stockage fonctionnel.
              </p>
            </div>
          </div>

          <div className="bg-gray-50 rounded-2xl p-12 mb-20">
            <h2 className="text-3xl font-bold text-center mb-12">Ce Que Nos Clients Disent</h2>
            <div className="grid md:grid-cols-2 gap-8">
              {testimonials.map((testimonial, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-lg">
                  <div className="flex items-center mb-4">
                    <img 
                      src={testimonial.image} 
                      alt={testimonial.name}
                      className="w-16 h-16 rounded-full mr-4"
                    />
                    <div>
                      <h4 className="font-semibold">{testimonial.name}</h4>
                      <p className="text-gray-600">{testimonial.role}</p>
                    </div>
                  </div>
                  <p className="text-gray-600 italic">"{testimonial.content}"</p>
                </div>
              ))}
            </div>
          </div>

          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-6">Prêt à Démarrer Votre Projet ?</h2>
            <p className="text-xl text-gray-600 mb-8">
              Nos experts sont à votre disposition pour étudier votre projet et vous proposer la solution la plus adaptée à vos besoins.
            </p>
            <Link 
              to="/contact"
              className="inline-block bg-[#2F4F2F] text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-opacity-90 transition-all"
            >
              Contactez-nous Maintenant
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}