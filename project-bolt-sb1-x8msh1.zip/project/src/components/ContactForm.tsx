import React from 'react';
import { PopupButton } from '@typeform/embed-react';
import { Mail, Phone, MapPin } from 'lucide-react';

export default function ContactForm() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-6">Étudier Mon Projet Gratuitement</h1>
            <p className="text-xl text-gray-600">
              Remplissez notre formulaire détaillé pour recevoir une étude personnalisée de votre projet
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <h2 className="text-2xl font-semibold mb-6">Contactez-nous directement</h2>
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <Phone className="w-6 h-6 mr-4 text-[#2F4F2F]" />
                  <div>
                    <p className="font-semibold">Téléphone</p>
                    <a href="tel:0663932444" className="text-gray-600 hover:text-[#2F4F2F]">
                      06.63.93.24.44
                    </a>
                  </div>
                </div>
                <div className="flex items-center">
                  <Mail className="w-6 h-6 mr-4 text-[#2F4F2F]" />
                  <div>
                    <p className="font-semibold">Email</p>
                    <a href="mailto:bureaudetudebf26@gmail.com" className="text-gray-600 hover:text-[#2F4F2F]">
                      bureaudetudebf26@gmail.com
                    </a>
                  </div>
                </div>
                <div className="flex items-center">
                  <MapPin className="w-6 h-6 mr-4 text-[#2F4F2F]" />
                  <div>
                    <p className="font-semibold">Adresse</p>
                    <p className="text-gray-600">
                      8 rue de la convention<br />
                      69100 VILLEURBANNE
                    </p>
                  </div>
                </div>
              </div>

              <div className="w-full h-64 rounded-lg overflow-hidden">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2783.2835673075897!2d4.886281776271842!3d45.76006587108091!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47f4c0213d1a6f3d%3A0x2a8f2f4b7c7c7c7c!2s8%20Rue%20de%20la%20Convention%2C%2069100%20Villeurbanne!5e0!3m2!1sfr!2sfr!4v1620000000000!5m2!1sfr!2sfr"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg">
              <h2 className="text-2xl font-semibold mb-6">Formulaire d'étude gratuite</h2>
              <p className="text-gray-600 mb-8">
                Remplissez notre formulaire détaillé pour recevoir une étude personnalisée et un devis gratuit pour votre projet de hangar photovoltaïque.
              </p>
              <PopupButton 
                id="gRY5DeMb"
                className="w-full bg-[#9FE870] text-[#2F4F2F] px-8 py-4 rounded-full text-lg font-semibold hover:bg-opacity-90 transition-all text-center"
              >
                Commencer l'étude →
              </PopupButton>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}